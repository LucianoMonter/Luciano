// Objetos

// const persona1 = {
//   nombre: "Homero",
//   edad: 39,
//   calle: "Av. siempreviva 742"
// };

// console.log(persona1);
// console.log(persona1.nombre);
// console.log(persona1.edad);
// console.log(persona1.calle);

// persona1.nombre = "Marge";
// persona1.edad = 36;

// console.log(persona1);



// Funciones constructoras

// function Persona(nombre, edad, calle) {
//   this.nombre = nombre;
//   this.edad = edad;
//   this.calle = calle;
// };

// const persona1 = new Persona("Homero", 39, "Av. siempreviva 742");
// const persona2 = new Persona("Marge", 36, "Av. siempreviva 742");

// console.log(persona1);

// console.log(persona1.nombre);
// console.log(persona1.edad);
// console.log(persona1.calle);

// console.log(persona2.nombre);
// console.log(persona2.edad);
// console.log(persona2.calle);



// function Product(name, price, year) {
//   this.name = name;
//   this.price = price;
//   this.year = year;
// };

// const product1 = new Product("Aceite", 900, 2032);
// console.log(product1);



// Métodos personalizados

// function Persona(nombre, edad, calle) {
//   this.nombre = nombre;
//   this.edad = edad;
//   this.calle = calle;

//   this.hablar = function() {
//     console.log("Hola mi nombre es: "+this.nombre);
//   };

//   this.identificarse = function() {
//     console.log("Hola soy: "+this.nombre+" y mi edad es: "+this.edad);
//   };
// };

// const persona1 = new Persona("Homero", 39, "Av. siempreviva 742");
// const persona2 = new Persona("Marge", 36, "Av. siempreviva 742");

// persona1.hablar();
// persona1.identificarse();

// persona2.hablar();



// Operador in y for in

// const persona1 = {
//   nombre: "Homero",
//   edad: 39,
//   calle: "Av. siempreviva 742"
// };

// // console.log("edad" in persona1); // true
// // console.log("correo" in persona1); // false

// for (const propiedad in persona1) {
//   console.log(persona1[propiedad]);
// };



// class Producto {
//   constructor (nombre, precio) {
//     this.nombre = nombre;
//     this.precio = precio;
//     this.vendido = false;
//   }

//   sumarIva() {
//     this.precio = this.precio * 1.21;
//   };

//   vender() {
//     this.vendido = true;
//   };
// };

// const producto1 = new Producto("Aceite", 900);
// const producto2 = new Producto("Harina", 1900);

// producto1.sumarIva();
// producto1.vender();
// console.log(producto1);

// producto2.sumarIva()
// console.log(producto2);



class Pedido {
  constructor (producto, precio, cantidad) {
    this.producto = producto;
    this.precio = precio;
    this.cantidad = cantidad;
    this.subtotal = 0;
    this.envio = 0;
    this.total = 0;
  }

  calcularSubtotal() {
    this.subtotal = this.precio * this.cantidad;
  };

  calcularEnvio() {
    if (this.subtotal > 5000) {
      this.envio = 0;
    } else {
      this.envio = 1000;
    }
  };

  calcularTotal() {
    this.total = this.subtotal + this.envio;
  };
};

const pedido1 = new Pedido("Aceite", 900, 2);

// Calculamos el subtotal
pedido1.calcularSubtotal();
console.log(pedido1);

// Calculamos el envío
pedido1.calcularEnvio();
console.log(pedido1);

// Calculamos el total
pedido1.calcularTotal();
console.log(pedido1);

