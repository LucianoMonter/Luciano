// Arrays

// const numeros = [2, 1, 3, 5, 6, 8];

// console.log(numeros[2]); // 3
// console.log(numeros[1]); // 1
// console.log(numeros[0]); // 2
// console.log(numeros[5]); // 8

// let resultado1 = numeros[4] + numeros[2];
// console.log(resultado1);


// Recorrer un array

// const numeros = [2, 1, 3, 5, 6, 8];

// for (let i=0; i<6; i++) {
//   console.log(numeros[i]);
// };


// Propiedad length

// const numeros = [2, 1, 3, 5, 6, 9, 10, 45, 3, 1];

// for (let i=0; i<numeros.length; i++) {
//   console.log(numeros[i]);
// };



// Métodos de arrays

// push()
// const datos = ["Hola", 45, "Coder"];
// console.log(datos);

// datos.push("Otro elemento", "House", 34);
// console.log(datos);


// unshift()
// const datos = ["Hola", 45, "Coder"];
// console.log(datos);

// datos.unshift("otro elemento");
// console.log(datos);


// splice()
// const usuarios = ["Rita", "Mateo", "Juan", "Ana", "Jose", "Julia"];

// usuarios.splice(3, 1);
// usuarios.splice(1, 1);
// usuarios.splice(1, 4);
// console.log(usuarios);


// join()
// const usuarios = ["Rita", "Mateo", "Juan", "Ana", "Jose", "Julia"];

// alert(usuarios.join("\n"));


// concat()

// const perros = ["Firulais", "Rocky", "Apolo"];
// const perros2 = ["Chester"];
// const gatos = ["Mishi", "Sasha"];

// const mascotas = perros.concat(gatos, perros2);
// console.log(mascotas);
// console.log(perros);
// console.log(gatos);


// indexOf()

// const usuarios = ["Rita", "Mateo", "Juan", "Ana", "Jose", "Julia"];

// console.log(usuarios.indexOf("Ana"));
// console.log(usuarios.indexOf("Rita"));
// console.log(usuarios.indexOf("Mateo"));
// console.log(usuarios.indexOf("Rocky"));

// console.log(usuarios.includes("Ana"));
// console.log(usuarios.includes("Rita"));
// console.log(usuarios.includes("Mateo"));
// console.log(usuarios.includes("Rocky"));

// const usuarioPermisos = ["crear", "eliminar", "editar"];

// if (usuarioPermisos.includes("eliminar")) {
//   // Mostrar botón eliminar
// }


// Ejemplo aplicado

// const usuarios = ["Rita", "Mateo", "Juan", "Ana", "Jose", "Julia"];

// const eliminarUsuario = (usuarioNombre) => {
//   let index = usuarios.indexOf(usuarioNombre);
//   console.log(index)
//   if (index != -1) {
//     usuarios.splice(index, 1);
//   } else {
//     alert("El usuario no existe!");
//   }
// };

// function eliminarUsuario(usuarioNombre) {
//   // Escribimos el resto del código
// }

// eliminarUsuario("Mateo");

// console.log(usuarios);


// Sentencia for of

// const productos = [
//   { id:1, nombre:"Aceite", precio:900 },
//   { id:2, nombre:"Pan", precio:100 },
//   { id:3, nombre:"Harina", precio:1000 }
// ];

// for (const producto of productos) {
//   console.log(producto.nombre);
//   console.log(producto.precio);
// }


// Ejemplos de array de objetos - To Do List

// const tareas = [
//   {
//     id:1,
//     nombre:"Leer un libro",
//     descripcion:"Por una hora",
//     completado: false
//   },
//   {
//     id:2,
//     nombre:"Pasear al perro",
//     descripcion:"Por una hora",
//     completado: false
//   },
// ];


class Tarea {
  constructor (nombre, descripcion) {
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.completado = false;
  }

  completarTarea() {
    this.completado = true;
  }
};

const tareas = [];
let agregarTarea = false;
let nombre = "";
let descripcion = "";

do {
  nombre = prompt("Agregue el nombre de la tarea:");
  descripcion = prompt("Agregue el descripción de la tarea:");

  let tarea = new Tarea(nombre, descripcion);
  tareas.push(tarea);

  agregarTarea = confirm("Desea agregar otra tarea?");
} while (agregarTarea);


// const tarea1 = new Tarea("Leer un libro", "Por una hora");
// const tarea2 = new Tarea("Pasear al perro", "Por una hora");

// tareas.push(tarea1, tarea2);
// console.log(tareas);

// for (const tarea of tareas) {
//   tarea.completarTarea();
// }

console.log(tareas);